
package rede;

import javax.swing.JOptionPane;

import InterfaceGrafica.GUITela;
import lenChoa.Tabuleiro;
import lenChoa.Jogador;

public class AtorJogador {
    
    private Tabuleiro tabuleiro;
    private AtorRede atorRede;
    private String idUsuario;
    private GUITela tela;
    
    public AtorJogador(GUITela tela) {
        super();
        atorRede = new AtorRede(this);
        setGUITela(tela);
        tabuleiro = new Tabuleiro();
        tabuleiro.iniciar();
    }
    
    public  GUITela informarInterface() {
        return tela;
    }
    
    public void iniciarNovaPartida(Integer posicao) {
        tabuleiro.criarJogador(idUsuario);
        String idJogador = atorRede.informarNomeAdversario(idUsuario);
        tabuleiro.criarJogador(idJogador);
        tabuleiro.iniciarPartida(posicao);
    }
    
    public int conectar() {
        boolean conectado = tabuleiro.isConectado();
        if (!conectado){
            String servidor = this.obterDadosConexao();
            //idUsuario = "netbeans";
            boolean exito = atorRede.conectar(idUsuario, servidor);
            if (exito){
                tabuleiro.setConectado(true);
                return 0;
            } else {
                return 2;
            }			
        }else{
            return 1;
        }		
    }
    
     public int desconectar() {
        boolean conectado = tabuleiro.isConectado();
        if (conectado){
            boolean exito = atorRede.desconectar();
            if (exito){
                tabuleiro.setConectado(false);
                return 3;
            } else {
                return 5;
            }			
        } else {
            return 4;
        }			
    }
     
     public int iniciarPartida() {
         boolean partidaEmAndamento = tabuleiro.isPartidaEmAndamento();
         boolean interromper = false;
         boolean conectado = false;
         
         if (partidaEmAndamento) {
            interromper = true;
         } else {
             conectado = tabuleiro.isConectado();
         }
         if (interromper || ((!partidaEmAndamento) && conectado)){
             atorRede.iniciarPartida();
             return 6;
         }
         if (!conectado) {
             return 7;
         }
         return 13;
    }
  
    
    public String obterDadosConexao() {
        idUsuario = JOptionPane.showInputDialog("Informe o id do usuario.");
        String servidor = JOptionPane.showInputDialog("Informe o id do servidor.");
        return servidor;
    }

    public void setGUITela(GUITela tela) {
        this.tela = tela;
    }

    public boolean conectado() {
        return tabuleiro.isConectado();
    }
    
    public boolean emAndamento() {
        return tabuleiro.isPartidaEmAndamento();
    }

    public Tabuleiro getTabuleiro() {
        return tabuleiro;
    }

}
