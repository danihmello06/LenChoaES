package lenChoa;
import javax.swing.JOptionPane;
import rede.Lance;

public class Tabuleiro {

	private Jogador jogador1;
	private Jogador jogador2;
	private boolean conectado;
	private boolean partidaEmAndamento, partidaTerminada;
	private boolean j1Pronto, j2Pronto, desordenada;
	private int fase;

	public Tabuleiro() {

	}

	

	public void iniciar() {
		jogador1 = null;
		jogador2 = null;
		partidaEmAndamento = false;
	}

	public Lance informarJogada(Jogador jogador, int apostadas) {
		Lance lance = new Lance();
		lance.setJogador(jogador);
		lance.setFichas(apostadas);
		return lance;
	}

	public Lance informarJogada(int qualCarta, Jogador jogador) {
		Lance lance = new Lance();
		lance.setJogador(jogador);
		lance.setQualCarta(qualCarta);
		return lance;
	}

	public boolean isConectado() {
		return conectado;
	}

	public void setConectado(boolean conectado) {
		this.conectado = conectado;
	}

	public boolean isPartidaEmAndamento() {
		return partidaEmAndamento;
	}

	public void setPartidaEmAndamento(boolean partidaEmAndamento) {
		this.partidaEmAndamento = partidaEmAndamento;
	}

	

	public void criarJogador(String idUsuario) {
		if (jogador1 == null) {
			jogador1 = new Jogador();
			jogador1.iniciar();
			jogador1.setNome(idUsuario);
		} else {
			jogador2 = new Jogador();
			jogador2.iniciar();
			jogador2.setNome(idUsuario);
		}
	}

	public void iniciarPartida(Integer posicao) {
		partidaEmAndamento = true;
		if(posicao == 1){
			jogador1.setTurno(true);
			JOptionPane.showMessageDialog(null, "Seu turno");
		}else{
			jogador2.setTurno(true);
		}
		fase = 0;
	}

	

	public Jogador getJogador1() {
		return jogador1;
	}

	public Jogador getJogador2() {
		return jogador2;
	}

	
	public Lance informarJogada(Jogador jogador) {
		Lance lance = new Lance();
		lance.setJogador(jogador);
		return lance;
	}

	
	public int getFase() {
		return fase;
	}


	public Lance informarJogada(Jogador jogador, boolean b) {
		Lance lance = new Lance();
		lance.setJogador(jogador);
		lance.setCheck(b);
		return lance;    
	}

	

}
