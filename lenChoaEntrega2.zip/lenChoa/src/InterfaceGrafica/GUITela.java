package InterfaceGrafica;
import rede.AtorJogador;

import java.awt.Dimension;

import javax.swing.Box.Filler;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu.Separator;

import rede.AtorJogador;

public class GUITela extends javax.swing.JFrame {

	private static AtorJogador atorJogador;


	public static void main(String[] args) {
		GUITela telaJogo01 = new GUITela();
		telaJogo01.setSize(800,638);
		telaJogo01.setVisible(true);
	}

	public GUITela() {

		atorJogador = new AtorJogador(this);
		initComponents();
	}

	public void initComponents(){

		JPanel jPanel1 = new JPanel();
		JMenu jMenu1 = new JMenu();
		JMenuBar jMenuBar1 = new JMenuBar();
		JMenuItem menuIniciarPartida = new JMenuItem();
		JMenuItem menuConectar = new JMenuItem();
		JMenuItem menuDesconectar = new JMenuItem();

		menuIniciarPartida.setText("Iniciar nova partida");
		menuConectar.setText("Conectar");	
		menuDesconectar.setText("Desconectar");

		jMenu1.add(menuConectar);
		jMenu1.add(menuDesconectar);
		jMenu1.add(menuIniciarPartida);

		jMenuBar1.add(jMenu1);

		setJMenuBar(jMenuBar1);

		Filler filler1 = new Filler(new Dimension(400, 400), new Dimension(400, 400), new Dimension(400, 400));
		Filler filler2 = new Filler(new Dimension(400, 400), new Dimension(400, 400), new Dimension(400, 400));
		Filler filler3 = new Filler(new Dimension(400, 400), new Dimension(400, 400), new Dimension(400, 400));
		Filler filler4 = new Filler(new Dimension(400, 400), new Dimension(400, 400), new Dimension(400, 400));
		Filler filler5 = new Filler(new Dimension(400, 400), new Dimension(400, 400), new Dimension(400, 400));
		Filler filler6 = new Filler(new Dimension(400, 400), new Dimension(400, 400), new Dimension(400, 400));
		Filler filler7 = new Filler(new Dimension(400, 400), new Dimension(400, 400), new Dimension(400, 400));
		Filler filler8 = new Filler(new Dimension(400, 400), new Dimension(400, 400), new Dimension(400, 400));
		Filler filler9 = new Filler(new Dimension(400, 400), new Dimension(400, 400), new Dimension(400, 400));
		Filler filler10 = new Filler(new Dimension(400, 400), new Dimension(400, 400), new Dimension(400, 400));
		Filler filler11 = new Filler(new Dimension(400, 400), new Dimension(400, 400), new Dimension(400, 400));
		Filler filler12 = new Filler(new Dimension(400, 400), new Dimension(400, 400), new Dimension(400, 400));
		Filler filler13 = new Filler(new Dimension(400, 400), new Dimension(400, 400), new Dimension(400, 400));
		Filler filler14 = new Filler(new Dimension(400, 400), new Dimension(400, 400), new Dimension(400, 400));
		Filler filler15 = new Filler(new Dimension(400, 400), new Dimension(400, 400), new Dimension(400, 400));
		Filler filler16 = new Filler(new Dimension(400, 400), new Dimension(400, 400), new Dimension(400, 400));
		Filler filler17 = new Filler(new Dimension(400, 400), new Dimension(400, 400), new Dimension(400, 400));
		Filler filler18 = new Filler(new Dimension(400, 400), new Dimension(400, 400), new Dimension(400, 400));

		JLabel jLabel1 = new JLabel();
		JLabel jLabel2 = new JLabel();
		JLabel jLabel3 = new JLabel();
		JLabel jLabel4 = new JLabel();
		JLabel jLabel5 = new JLabel();
		JLabel jLabel6 = new JLabel();
		JLabel jLabel7 = new JLabel();
		JLabel jLabel8 = new JLabel();

		jPanel1.add(filler1);
		jPanel1.add(filler2);
		jPanel1.add(filler3);
		jPanel1.add(filler4);
		jPanel1.add(filler5);
		jPanel1.add(filler6);
		jPanel1.add(filler7);
		jPanel1.add(filler8);
		jPanel1.add(filler9);
		jPanel1.add(filler10);
		jPanel1.add(filler11);
		jPanel1.add(filler12);
		jPanel1.add(filler13);
		jPanel1.add(filler14);
		jPanel1.add(filler15);
		jPanel1.add(filler16);
		jPanel1.add(filler17);
		jPanel1.add(filler18);

		filler1.setBounds(380, 70, 50, 50);
		filler2.setBounds(310, 210, 40, 40);
		filler3.setBounds(380, 210, 40, 40);
		filler4.setBounds(450, 210, 40, 40);
		filler5.setBounds(230, 345, 45, 45);
		filler6.setBounds(380, 350, 40, 40);
		filler7.setBounds(530, 350, 40, 40);
		filler8.setBounds(160, 480, 40, 40);
		filler9.setBounds(380, 480, 40, 40);
		filler10.setBounds(600, 480, 40, 40);
		filler12.setBounds(40, 60, 50, 50);
		filler13.setBounds(40, 150, 50, 50);
		filler15.setBounds(40, 230, 50, 50);
		filler16.setBounds(40, 320, 50, 50);
		filler17.setBounds(40, 400, 50, 50);
		filler18.setBounds(40, 480, 50, 50);

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);

		jPanel1.setLayout(null);

		jLabel2.setIcon(new ImageIcon(getClass().getResource("/Imagens/leopard.png")));
		jLabel2.setPreferredSize(new java.awt.Dimension(48, 48));
		jPanel1.add(jLabel2);
		jLabel2.setBounds(40, 60, 50, 50);

		jLabel4.setIcon(new ImageIcon(getClass().getResource("/Imagens/tiger.png")));
		jLabel4.setName("jLabel1"); // NOI18N
		jPanel1.add(jLabel4);
		jLabel4.setBounds(380, 70, 50, 50);

		jLabel3.setIcon(new ImageIcon(getClass().getResource("/Imagens/leopard.png"))); // NOI18N
		jPanel1.add(jLabel3);
		jLabel3.setBounds(40, 150, 50, 50);

		jLabel5.setIcon(new ImageIcon(getClass().getResource("/Imagens/leopard.png"))); // NOI18N
		jPanel1.add(jLabel5);
		jLabel5.setBounds(40, 230, 50, 50);

		jLabel6.setIcon(new ImageIcon(getClass().getResource("/Imagens/leopard.png"))); // NOI18N
		jPanel1.add(jLabel6);
		jLabel6.setBounds(40, 320, 50, 50);

		jLabel7.setIcon(new ImageIcon(getClass().getResource("/Imagens/leopard.png"))); // NOI18N
		jPanel1.add(jLabel7);
		jLabel7.setBounds(40, 400, 50, 50);

		jLabel8.setIcon(new ImageIcon(getClass().getResource("/Imagens/leopard.png"))); // NOI18N
		jPanel1.add(jLabel8);
		jLabel8.setBounds(40, 480, 50, 50);


		menuConectar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	conectar();
            }
        });

		menuDesconectar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	desconectar();
            }
        });
		
		menuIniciarPartida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
            	iniciarPartida();
            }
        });
		
		filler1.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				//jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\danih\\Documents\\NetBeansProjects\\LenChoaGame\\src\\main\\java\\lenChoa\\resources\\tigerSelected.png"));// TODO add your handling code here:
				JOptionPane.showMessageDialog(null, "Posicao 1 clicada");
			}
		});

		filler2.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				//jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\danih\\Documents\\NetBeansProjects\\LenChoaGame\\src\\main\\java\\lenChoa\\resources\\tigerSelected.png"));// TODO add your handling code here:
				JOptionPane.showMessageDialog(null, "Posicao 2 clicada");
			}
		});

		filler3.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				//jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\danih\\Documents\\NetBeansProjects\\LenChoaGame\\src\\main\\java\\lenChoa\\resources\\tigerSelected.png"));// TODO add your handling code here:
				JOptionPane.showMessageDialog(null, "Posicao 3 clicada");
			}
		});

		filler4.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				//jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\danih\\Documents\\NetBeansProjects\\LenChoaGame\\src\\main\\java\\lenChoa\\resources\\tigerSelected.png"));// TODO add your handling code here:
				JOptionPane.showMessageDialog(null, "Posicao 4 clicada");
			}
		});

		filler5.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				//jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\danih\\Documents\\NetBeansProjects\\LenChoaGame\\src\\main\\java\\lenChoa\\resources\\tigerSelected.png"));// TODO add your handling code here:
				JOptionPane.showMessageDialog(null, "Posicao 5 clicada");
			}
		});

		filler6.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				//jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\danih\\Documents\\NetBeansProjects\\LenChoaGame\\src\\main\\java\\lenChoa\\resources\\tigerSelected.png"));// TODO add your handling code here:
				JOptionPane.showMessageDialog(null, "Posicao 6 clicada");
			}
		});

		filler7.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				//jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\danih\\Documents\\NetBeansProjects\\LenChoaGame\\src\\main\\java\\lenChoa\\resources\\tigerSelected.png"));// TODO add your handling code here:
				JOptionPane.showMessageDialog(null, "Posicao 7 clicada");
			}
		});

		filler8.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				//jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\danih\\Documents\\NetBeansProjects\\LenChoaGame\\src\\main\\java\\lenChoa\\resources\\tigerSelected.png"));// TODO add your handling code here:
				JOptionPane.showMessageDialog(null, "Posicao 8 clicada");
			}
		});

		filler9.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				//jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\danih\\Documents\\NetBeansProjects\\LenChoaGame\\src\\main\\java\\lenChoa\\resources\\tigerSelected.png"));// TODO add your handling code here:
				JOptionPane.showMessageDialog(null, "Posicao 9 clicada");
			}
		});

		filler10.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				//jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\danih\\Documents\\NetBeansProjects\\LenChoaGame\\src\\main\\java\\lenChoa\\resources\\tigerSelected.png"));// TODO add your handling code here:
				JOptionPane.showMessageDialog(null, "Posicao 10 clicada");
			}
		});

		filler12.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				//jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\danih\\Documents\\NetBeansProjects\\LenChoaGame\\src\\main\\java\\lenChoa\\resources\\tigerSelected.png"));// TODO add your handling code here:
				JOptionPane.showMessageDialog(null, "Posicao 11 clicada");
			}
		});

		filler13.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				//jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\danih\\Documents\\NetBeansProjects\\LenChoaGame\\src\\main\\java\\lenChoa\\resources\\tigerSelected.png"));// TODO add your handling code here:
				JOptionPane.showMessageDialog(null, "Posicao 12 clicada");
			}
		});

		filler15.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				//jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\danih\\Documents\\NetBeansProjects\\LenChoaGame\\src\\main\\java\\lenChoa\\resources\\tigerSelected.png"));// TODO add your handling code here:
				JOptionPane.showMessageDialog(null, "Posicao 13 clicada");
			}
		});

		filler16.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				//jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\danih\\Documents\\NetBeansProjects\\LenChoaGame\\src\\main\\java\\lenChoa\\resources\\tigerSelected.png"));// TODO add your handling code here:
				JOptionPane.showMessageDialog(null, "Posicao 14 clicada");
			}
		});

		filler17.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				//jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\danih\\Documents\\NetBeansProjects\\LenChoaGame\\src\\main\\java\\lenChoa\\resources\\tigerSelected.png"));// TODO add your handling code here:
				JOptionPane.showMessageDialog(null, "Posicao 15 clicada");
			}
		});

		filler18.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				//jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\danih\\Documents\\NetBeansProjects\\LenChoaGame\\src\\main\\java\\lenChoa\\resources\\tigerSelected.png"));// TODO add your handling code here:
				JOptionPane.showMessageDialog(null, "Posicao 16 clicada");
			}
		});

		jLabel1.setIcon(new ImageIcon(getClass().getResource("/Imagens/TelaJogo02.jpg"))); // NOI18N
		jPanel1.add(jLabel1);
		jLabel1.setBounds(0, 0, 800, 600);

		getContentPane().add(jPanel1);
		jPanel1.setBounds(0, 0, 800, 600);

		jMenu1.setText("Jogo");
		jMenu1.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				//jMenu1MouseClicked(evt);
			}
		});



	}

	public void conectar() {
		int resultado = atorJogador.conectar();
		notificarResultado(resultado);
	}

	public void desconectar() {
		int resultado = atorJogador.desconectar();
		notificarResultado(resultado);
	}

	public void iniciarPartida() {
		int resultado = atorJogador.iniciarPartida();
		notificarResultado(resultado);
	}

	private void notificarResultado(int resultado) {
		switch (resultado) {
		case 0:  JOptionPane.showMessageDialog(this, "Conexao efetuada com exito"); break;        	
		case 1:  JOptionPane.showMessageDialog(this, "Tentativa de conexao com conexao previamente estabelecida"); break;
		case 2:  JOptionPane.showMessageDialog(this, "Tentativa de conexao falhou"); break;
		case 3:  JOptionPane.showMessageDialog(this, "Desonexao efetuada com exito"); break;
		case 4:  JOptionPane.showMessageDialog(this, "Tentativa de desconexao sem conexao previamente estabelecida"); break;
		case 5:  JOptionPane.showMessageDialog(this, "Tentativa de desconexao falhou"); break;
		case 6:  JOptionPane.showMessageDialog(this, "Solicitacao de inicio procedida com exito"); break;
		case 7:  JOptionPane.showMessageDialog(this, "Tentativa de inicio sem conexao previamente estabelecida"); break;
		case 8:  JOptionPane.showMessageDialog(this, "Nao eh a sua vez"); break;
		case 9:  JOptionPane.showMessageDialog(this, "Partida encerrada"); break;
		case 10: JOptionPane.showMessageDialog(this, "Lance OK"); break;
		case 11: JOptionPane.showMessageDialog(this, "Nao usado"); break;
		case 12: JOptionPane.showMessageDialog(this, "Jogada invalida"); break;
		case 13: JOptionPane.showMessageDialog(this, "Partida corrente nao interrompida"); break;
		case 14: JOptionPane.showMessageDialog(this, "Proxima fase"); break;
		case 15: JOptionPane.showMessageDialog(this, "So pode dar check se tiver menos fichas apostadas que o adversario");
		}
	}











}
